<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <title>Tela de cadastro de reserva</title>
   </head>
     
     <body>

<?php

$nome= $_GET["nome]

echo"<h1>Bem vindo usuário:$nome</h1>";

echo "<pre>";
var_export($ GET);
echo "</pre>";
?>

</body> 

</html>